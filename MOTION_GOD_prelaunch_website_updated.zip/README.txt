MOTION GOD WEBSITE — PRE-LAUNCH VERSION

Open index.html in a browser to view the working site.

IMPORTANT:
This version intentionally does NOT accept paid massage bookings. It has an interest/waitlist form and a planned services menu, because Tennessee law requires the appropriate massage practitioner authorization and can require massage-establishment licensure for compensated massage. Confirm your exact current status and requirements with the Tennessee Department of Health/Massage Licensure Board before turning on booking.

The interest form currently saves submissions in the browser's localStorage only. Before publishing, connect it to a real form/email service or backend.

Next production steps:
1. Confirm your Tennessee massage therapist license pathway/status.
2. Confirm whether your home studio needs an establishment license and satisfy applicable requirements.
3. Confirm local business-license, zoning/home-business, insurance and tax requirements.
4. Add a real booking/payment provider only after the above are cleared.
5. Add intake/consent, cancellation, privacy and client-data procedures.
6. Replace product "Coming soon" badges with actual inventory/checkout when ready.
